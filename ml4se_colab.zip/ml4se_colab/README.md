# jupyter_ml4se
Jupyter notebooks for sample scripts from 「ITエンジニアのための機械学習理論入門」

Disclaimer: This is not an official Google product.
